﻿--CREATE TABLE catches (
--	id int IDENTITY(1,1) PRIMARY KEY,
--	fisherName varchar(255),
--	fishType varchar(255), 
--	fishWeight int,
--	place varchar(255),
--	weekNo int
--);

--INSERT INTO catches (fisherName, fishType, fishWeight, place, weekNo) VALUES ('Bent Jensen', 'Gede', 8, 'Roskilde', 41);
--INSERT INTO catches (fisherName, fishType, fishWeight, place, weekNo) VALUES ('Michael Hansen', 'Fladfisk', 1.5, 'Esbjerg', 38);
--INSERT INTO catches (fisherName, fishType, fishWeight, place, weekNo) VALUES ('Johnny Madsen', 'Skalle', 3, 'Fanø', 22);
SELECT * FROM catches;